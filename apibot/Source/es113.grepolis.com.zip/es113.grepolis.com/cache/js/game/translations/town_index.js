/*global _*/

(function() {
    "use strict";

    DM.loadData({
        l10n: {
            town_index: {
                window_title: _('City view'),
                tabs: [
                    _('Index')
                ]
            }
        } // l10n
    });
}());