(function() {
    "use strict";

    DM.loadData({
        l10n: {
            gifts_welcome: {
                window_title: _("Default window title"),
                tabs: [_("Tab 1"), _("Tab 2")],
                button_caption: _("Accept present")
            }
        }
    });
}());