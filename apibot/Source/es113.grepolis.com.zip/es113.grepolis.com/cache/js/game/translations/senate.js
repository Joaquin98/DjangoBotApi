/*global _*/

(function() {
    "use strict";

    DM.loadData({
        'l10n': {
            'senate': {
                "window_title": _('Senate'),
                "tabs": [
                    _('Index')
                ]
            }
        } // l10n
    });
}());