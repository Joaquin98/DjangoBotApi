/*global _, s*/

(function() {
    "use strict";

    DM.loadData({
        l10n: {
            overviews: {
                town_groups: {

                }
            }
        } // l10n
    });
}());