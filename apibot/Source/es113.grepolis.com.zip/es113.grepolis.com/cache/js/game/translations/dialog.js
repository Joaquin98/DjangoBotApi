/*globals _ */
(function() {
    "use strict";

    DM.loadData({
        'l10n': {
            'dialog': {
                "window_title": _('Dialogue'),
                "tabs": [
                    _('Index')
                ]
            }
        } // l10n
    });
}());