(function() {
    "use strict";

    DM.loadData({
        l10n: {
            island: {
                window_title: _('Island info'),
                tabs: [_('Index')]
            }
        }
    });
}());