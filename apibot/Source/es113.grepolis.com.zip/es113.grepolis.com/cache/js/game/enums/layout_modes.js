define('enums/layout_modes', function() {
    return {
        CITY_OVERVIEW: 'city_overview',
        ISLAND_VIEW: 'island_view',
        STRATEGIC_MAP: 'strategic_map'
    };
});