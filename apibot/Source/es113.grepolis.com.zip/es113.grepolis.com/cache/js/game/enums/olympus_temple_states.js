define('enums/olympus_temple_states', function() {
    return {
        UNDER_PROTECTION: 'under_protection',
        UNDER_SIEGE: 'under_siege'
    };
});