define('enums/end_game_types', function() {
    return {
        END_GAME_TYPE_DOMINATION: 'end_game_type_domination',
        END_GAME_TYPE_WONDER: 'end_game_type_world_wonder',
        END_GAME_TYPE_OLYMPUS: 'end_game_type_olympus'
    };
});