define('enums/unit_function', function() {
    return {
        NONE: 'function_none',
        OFFENSIVE: 'function_off',
        DEFENSIVE: 'function_def',
        OFFENSIVE_DEFENSIVE: 'function_both'
    };
});