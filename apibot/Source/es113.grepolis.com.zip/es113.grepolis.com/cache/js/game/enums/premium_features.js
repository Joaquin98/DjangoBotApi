define('enums/premium_features', function() {
    return {
        TYPE_COMMANDER: 'commander',
        TYPE_CURATOR: 'curator',
        TYPE_CAPTAIN: 'captain',
        TYPE_PRIEST: 'priest',
        TYPE_TRADER: 'trader'
    };
});