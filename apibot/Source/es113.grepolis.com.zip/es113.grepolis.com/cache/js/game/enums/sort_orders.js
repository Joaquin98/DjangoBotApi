define('enums/sort_orders', function(require) {
    "use strict";

    return {
        DEFAULT: 'default',
        ASC: 'asc',
        DESC: 'desc'
    };
});