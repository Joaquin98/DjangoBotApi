define('enums/artifacts', function() {
    'use strict';

    return {
        AMBROSIA: 'ambrosia',
        ATHENAS_CORNUCOPIA: 'athenas_cornucopia',
        GOLDEN_FLEECE: 'golden_fleece',
        PALLADION: 'palladion',
        SILVER_KANTHAROS: 'silver_kantharos',
        ZEUS_SPARK: 'zeus_spark'
    };
});