define('enums/last_stand_status', function() {
    return {
        ACTIVATION_POSSIBLE: 'activation_possible',
        NOT_REACHED: 'not_reached',
        ACTIVATED: 'activated'
    };
});