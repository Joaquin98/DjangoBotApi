define('enums/happenings', function() {
    return {
        UNDEFINED: 'undefined_happening',
        GREPOLYMPIA: 'grepolympia',
        MISSIONS: 'missions'
    };
});