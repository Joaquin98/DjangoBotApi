define('enums/questlog_categories', function() {
    return {
        DEFAULT_CATEGORY: 'default_category',
        ISLAND_QUESTS: 'island_quests'
    };
});