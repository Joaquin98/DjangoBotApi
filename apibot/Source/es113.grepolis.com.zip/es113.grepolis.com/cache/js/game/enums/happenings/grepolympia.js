define('enums/happenings/grepolympia', function() {
    return {
        HOPLITE_RACE: 'hoplite_race',
        ARCHERY: 'archery',
        JAVELIN_THROWING: 'javelin_throwing',
        CHARIOT_RACE: 'chariot_race',
        SHIELD_LUGE: 'shield_luge',
        WINTER_BIATHLON: 'winter_biathlon',
        FIGURE_SKATING: 'figure_skating',
        SKI_JUMP: 'ski_jump',
        MATCH_VS_ATHENTS: 'match_vs_athens',
        MATCH_VS_SPARTA: 'match_vs_sparta',
        MATCH_VS_CORINTH: 'match_vs_corinth',
        MATCH_VS_OLYMPUS: 'match_vs_olympus'
    };
});