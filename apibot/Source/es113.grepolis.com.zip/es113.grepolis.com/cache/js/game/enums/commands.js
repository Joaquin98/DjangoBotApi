define('enums/commands', function() {
    return {
        UNITS: 'MovementsUnits',
        SPY: 'MovementsSpy',
        REVOLT: 'MovementsRevolt',
        CONQUEROR: 'MovementsConqueror',
        COLONIZATION: 'MovementsColonization'
    };
});