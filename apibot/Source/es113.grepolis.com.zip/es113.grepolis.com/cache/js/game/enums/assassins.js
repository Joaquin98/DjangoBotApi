define('enums/assassins', function() {
    return {
        CAVALRY: 'cavalry',
        LEGIONARY: 'legionary',
        SAPPER: 'sapper'
    };
});