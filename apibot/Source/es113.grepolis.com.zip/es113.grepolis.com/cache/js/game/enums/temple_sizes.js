define('enums/temple_sizes', function(require) {
    "use strict";

    return {
        SMALL: 'small',
        LARGE: 'large',
        OLYMPUS: 'olympus'
    };
});