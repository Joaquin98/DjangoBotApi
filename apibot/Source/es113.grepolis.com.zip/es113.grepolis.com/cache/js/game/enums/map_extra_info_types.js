define('enums/map_extra_info_types', function() {
    return {
        ATTACK: 'attack',
        REVOLT: 'revolt',
        CONQUEST: 'conquest',
        TAKE_OVER: 'attack_takeover'
    };
});