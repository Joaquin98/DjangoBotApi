define('enums/quest_markers', function() {
    return {
        HIGHLIGHT: 'highlight'
    };
});