define('enums/player_hint_categories', function() {
    return {
        CONFIRMATION: 'confirmation',
        MAP: 'map'
    };
});