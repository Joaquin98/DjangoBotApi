define('enums/attack_table_box_enums', function() {
    return {
        ATTACK_TYPE: 'attack_type',
        ATTACK_STRATEGY: 'attack_strategy',
        ATTACK: 'attack',
        REGULAR: 'regular',
        SPELLS: 'spells',
        PORTAL_ATTACK_OLYMPUS: 'portal_attack_olympus'
    };
});