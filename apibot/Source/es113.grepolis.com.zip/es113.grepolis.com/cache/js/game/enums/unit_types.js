define('enums/unit_types', function() {
    return {
        GROUND: 'ground',
        NAVAL: 'naval'
    };
});