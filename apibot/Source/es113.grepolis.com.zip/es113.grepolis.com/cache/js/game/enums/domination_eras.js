define('enums/domination_eras', function() {
    return {
        PRE_DOMINATION: 'pre_domination',
        DOMINATION: 'domination',
        LAST_MAN_STANDING: 'last_stand',
        POST_DOMINATION: 'post_domination'
    };
});