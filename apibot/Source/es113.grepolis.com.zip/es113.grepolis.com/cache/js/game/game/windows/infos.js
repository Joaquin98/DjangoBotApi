define('game/game/infos', function() {
    return {
        MIN_SUPPORTED_WINDOW_WIDTH: 1024,
        MIN_SUPPORTED_WINDOW_HEIGHT: 768
    };
});