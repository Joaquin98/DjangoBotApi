define('game', function(require) {
    return window.Game;
});