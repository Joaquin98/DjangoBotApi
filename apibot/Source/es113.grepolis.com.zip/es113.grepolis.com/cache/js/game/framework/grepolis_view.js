/* globals Backbone */
/* @deprecated */
(function() {
    "use strict";

    var GrepolisView = Backbone.View.extend({

    });

    window.GrepolisView = GrepolisView;
}());